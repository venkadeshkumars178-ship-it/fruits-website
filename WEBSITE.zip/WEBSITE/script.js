// ==========================================
// FRESHBITE - MAIN JAVASCRIPT
// ==========================================


// ==========================================
// CART
// ==========================================

let cart = JSON.parse(localStorage.getItem("cart")) || [];


// ==========================================
// SAVE CART
// ==========================================

function saveCart() {
    localStorage.setItem("cart", JSON.stringify(cart));
}


// ==========================================
// UPDATE CART COUNT
// ==========================================

function addToCart(id, name, price) {

    const productId = Number(id);
    const productPrice = Number(price);

    const existingProduct = cart.find(
        product => Number(product.id) === productId
    );

    if (existingProduct) {

        existingProduct.quantity++;

    } else {

        cart.push({

            id: productId,

            name: String(name),

            price: productPrice,

            quantity: 1

        });

    }

    saveCart();

    updateCartCount();

    alert(`${name} added to cart!`);
}


// ==========================================
// PRODUCT DATA
// ==========================================

let products = [];


// ==========================================
// LOAD PRODUCTS FROM DATABASE
// ==========================================

async function loadProducts() {

    try {

        const response = await fetch(
            "http://localhost:5000/api/products"
        );

        const data = await response.json();

        if (!data.success) {

            console.error(
                "Unable to load products"
            );

            return;
        }

        products = data.products;

        displayProducts(products);

    } catch (error) {

        console.error(
            "Product loading error:",
            error
        );

        const productGrid =
            document.getElementById(
                "productGrid"
            );

        if (productGrid) {

            productGrid.innerHTML = `

                <div class="no-products">

                    <h2>
                        ⚠️ Unable to load fruits
                    </h2>

                    <p>
                        Please make sure the backend
                        server is running.
                    </p>

                </div>

            `;
        }
    }
}


// ==========================================
// DISPLAY PRODUCTS
// ==========================================

// ==========================================
// DISPLAY PRODUCTS
// ==========================================

function displayProducts(productList) {

    const productGrid = document.getElementById("productGrid");

    if (!productGrid) {
        return;
    }

    productGrid.innerHTML = "";

    if (!productList || productList.length === 0) {

        productGrid.innerHTML = `
            <div class="no-products">
                <h2>😔 No fruits found</h2>
                <p>Try searching for another fruit.</p>
            </div>
        `;

        return;
    }

    productList.forEach(product => {

        // Make sure values coming from PostgreSQL are handled correctly
        const productId = Number(product.id);
        const productName = String(product.name || "Unknown Fruit");
        const productPrice = Number(product.price) || 0;
        const productWeight = String(product.weight || "1 kg");
        const productImage = String(product.image_url || "🍎");

        const card = document.createElement("div");

        card.className = "product-card";

        card.innerHTML = `
            <div class="product-image">
                ${productImage}
            </div>

            <h3>${productName}</h3>

            <p class="product-weight">
                ${productWeight}
            </p>

            <div class="product-bottom">

                <span class="price">
                    ₹${productPrice.toFixed(2)}
                </span>

                <button
                    type="button"
                    class="add-cart">
                    + Add
                </button>

            </div>
        `;

        const addButton = card.querySelector(".add-cart");

        addButton.addEventListener("click", function () {

            addToCart(
                productId,
                productName,
                productPrice
            );

        });

        productGrid.appendChild(card);

    });

    updateCartCount();
}

// ==========================================
// CATEGORY FILTER
// ==========================================

function filterProducts(category) {

    const buttons =
        document.querySelectorAll(
            ".filter-btn"
        );

    buttons.forEach(button => {

        button.classList.remove("active");

    });


    try {

        const clickedButton =
            event?.currentTarget;

        if (clickedButton) {

            clickedButton.classList.add(
                "active"
            );

        }

    } catch (error) {

        // Ignore if event is unavailable

    }


    if (category === "all") {

        displayProducts(products);

    } else {

        const filteredProducts =
            products.filter(product =>
                product.category === category
            );

        displayProducts(filteredProducts);

    }
}


// ==========================================
// SEARCH PRODUCTS
// ==========================================

const searchInput =
    document.getElementById(
        "searchInput"
    );

if (searchInput) {

    searchInput.addEventListener(
        "input",
        function () {

            const searchText =
                this.value
                    .trim()
                    .toLowerCase();


            const filteredProducts =
                products.filter(product => {

                    const productName =
                        String(product.name)
                            .toLowerCase();

                    const productCategory =
                        String(product.category)
                            .toLowerCase();


                    return (
                        productName.includes(
                            searchText
                        ) ||

                        productCategory.includes(
                            searchText
                        )
                    );

                });


            displayProducts(
                filteredProducts
            );

        }
    );
}


// ==========================================
// INITIALIZE PRODUCTS PAGE
// ==========================================

if (
    document.getElementById(
        "productGrid"
    )
) {

    loadProducts();

}


// ==========================================
// SHOP NOW BUTTON
// ==========================================

const shopButton =
    document.querySelector(
        ".shop-btn"
    );

if (shopButton) {

    shopButton.addEventListener(
        "click",
        function () {

            const productsSection =
                document.querySelector(
                    ".products"
                );

            if (productsSection) {

                productsSection.scrollIntoView({
                    behavior: "smooth"
                });

            }

        }
    );

}


// ==========================================
// CART PAGE
// ==========================================

function displayCart() {

    const cartContainer =
        document.getElementById(
            "cartItems"
        );

    if (!cartContainer) {
        return;
    }


    cartContainer.innerHTML = "";


    // ==========================================
    // EMPTY CART
    // ==========================================

    if (cart.length === 0) {

        cartContainer.innerHTML = `

            <div class="empty-cart">

                <div class="empty-cart-icon">
                    🛒
                </div>

                <h2>
                    Your cart is empty
                </h2>

                <p>
                    Add some fresh fruits to your cart.
                </p>

                <a
                    href="products.html"
                    class="shop-empty-btn">

                    Shop Fruits

                </a>

            </div>

        `;

        updateCartSummary();

        return;
    }


    // ==========================================
    // DISPLAY CART PRODUCTS
    // ==========================================

    cart.forEach((product, index) => {

        const cartItem =
            document.createElement(
                "div"
            );

        cartItem.className =
            "cart-item";


        const price =
            Number(product.price) || 0;

        const quantity =
            Number(product.quantity) || 0;


        cartItem.innerHTML = `

            <div class="cart-product-image">

                ${getFruitEmoji(
                    product.name
                )}

            </div>


            <div class="cart-product-info">

                <h3>
                    ${product.name}
                </h3>

                <p>
                    ₹${price} / kg
                </p>

            </div>


            <div class="quantity-control">

                <button
                    type="button"
                    onclick="decreaseQuantity(${index})">

                    −

                </button>


                <span>
                    ${quantity}
                </span>


                <button
                    type="button"
                    onclick="increaseQuantity(${index})">

                    +

                </button>

            </div>


            <div class="cart-product-price">

                ₹${price * quantity}

            </div>


            <button
                type="button"
                class="remove-btn"
                onclick="removeFromCart(${index})">

                ✕

            </button>

        `;


        cartContainer.appendChild(
            cartItem
        );

    });


    // ==========================================
    // UPDATE SUMMARY
    // ==========================================

    updateCartSummary();

}


// ==========================================
// GET FRUIT EMOJI
// ==========================================

function getFruitEmoji(name) {

    const fruitName =
        String(name)
            .toLowerCase();


    if (
        fruitName.includes("apple")
    ) {

        return "🍎";

    }


    if (
        fruitName.includes("banana")
    ) {

        return "🍌";

    }


    if (
        fruitName.includes("orange")
    ) {

        return "🍊";

    }


    if (
        fruitName.includes("mango")
    ) {

        return "🥭";

    }


    if (
        fruitName.includes("grape")
    ) {

        return "🍇";

    }


    if (
        fruitName.includes("watermelon")
    ) {

        return "🍉";

    }


    return "🍎";
}


// ==========================================
// UPDATE CART SUMMARY
// ==========================================

function updateCartSummary() {

    // ------------------------------------------
    // Calculate subtotal
    // ------------------------------------------

    let subtotal = 0;


    cart.forEach(product => {

        const price =
            Number(product.price) || 0;

        const quantity =
            Number(product.quantity) || 0;


        subtotal +=
            price * quantity;

    });


    // ------------------------------------------
    // Delivery charge
    // ------------------------------------------

    let delivery = 0;


    if (
        subtotal > 0 &&
        subtotal < 500
    ) {

        delivery = 40;

    }


    // ------------------------------------------
    // Total
    // ------------------------------------------

    const total =
        subtotal + delivery;


    // ------------------------------------------
    // Update all possible summary elements
    // ------------------------------------------

    updateSummaryElements(
        "subtotal",
        `₹${subtotal}`
    );

    updateSummaryElements(
        "cartSubtotal",
        `₹${subtotal}`
    );


    updateSummaryElements(
        "delivery",
        delivery === 0
            ? "FREE"
            : `₹${delivery}`
    );

    updateSummaryElements(
        "cartDelivery",
        delivery === 0
            ? "FREE"
            : `₹${delivery}`
    );


    updateSummaryElements(
        "total",
        `₹${total}`
    );

    updateSummaryElements(
        "cartTotal",
        `₹${total}`
    );

}


// ==========================================
// UPDATE SUMMARY ELEMENTS
// ==========================================

function updateSummaryElements(
    id,
    value
) {

    const elements =
        document.querySelectorAll(
            `#${id}`
        );


    elements.forEach(element => {

        element.textContent = value;

    });

}


// ==========================================
// INCREASE QUANTITY
// ==========================================

function increaseQuantity(index) {

    if (!cart[index]) {
        return;
    }


    cart[index].quantity++;


    saveCart();

    displayCart();

    updateCartCount();

}


// ==========================================
// DECREASE QUANTITY
// ==========================================

function decreaseQuantity(index) {

    if (!cart[index]) {
        return;
    }


    if (
        Number(cart[index].quantity) > 1
    ) {

        cart[index].quantity--;

    } else {

        cart.splice(index, 1);

    }


    saveCart();

    displayCart();

    updateCartCount();

}


// ==========================================
// REMOVE PRODUCT
// ==========================================

function removeFromCart(index) {

    if (!cart[index]) {
        return;
    }


    cart.splice(index, 1);


    saveCart();

    displayCart();

    updateCartCount();

}


// ==========================================
// CHECKOUT
// ==========================================

function checkout() {

    if (cart.length === 0) {

        alert(
            "Your cart is empty. Please add some fruits first."
        );

        return;

    }


    window.location.href =
        "checkout.html";

}


// ==========================================
// INITIALIZE CART PAGE
// ==========================================

if (
    document.getElementById(
        "cartItems"
    )
) {

    displayCart();

}


// ==========================================
// INITIALIZE CART COUNT
// ==========================================

updateCartCount();


// ==========================================
// USER PROFILE
// ==========================================

function loadUserProfile() {

    const userData =
        localStorage.getItem(
            "user"
        );


    if (!userData) {

        window.location.href =
            "login.html";

        return;

    }


    try {

        const user =
            JSON.parse(userData);


        const name =
            document.getElementById(
                "profileName"
            );

        const email =
            document.getElementById(
                "profileEmail"
            );

        const phone =
            document.getElementById(
                "profilePhone"
            );

        const role =
            document.getElementById(
                "profileRole"
            );


        if (name) {

            name.value =
                user.full_name || "";

        }


        if (email) {

            email.value =
                user.email || "";

        }


        if (phone) {

            phone.value =
                user.phone ||
                "Not provided";

        }


        if (role) {

            role.value =
                user.role ||
                "customer";

        }

    } catch (error) {

        console.error(
            "Profile loading error:",
            error
        );

        localStorage.removeItem(
            "user"
        );

        localStorage.removeItem(
            "token"
        );

        window.location.href =
            "login.html";

    }

}


// ==========================================
// LOGOUT
// ==========================================

function logout() {

    localStorage.removeItem(
        "token"
    );

    localStorage.removeItem(
        "user"
    );


    alert(
        "You have been logged out."
    );


    window.location.href =
        "index.html";

}


// ==========================================
// LOAD PROFILE
// ==========================================

if (
    document.getElementById(
        "profileName"
    )
) {

    loadUserProfile();

}