// ==========================================
// FRESHBITE BACKEND SERVER
// ==========================================

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const pool = require("./db");

const app = express();
const PORT = 5000;

// ==========================================
// MIDDLEWARE
// ==========================================

app.use(cors());
app.use(express.json());

// ==========================================
// JWT SECRET
// ==========================================

const JWT_SECRET = "FRESHBITE_SECRET_KEY_CHANGE_LATER";

// ==========================================
// HOME / TEST
// ==========================================

app.get("/", (req, res) => {
    res.send("FreshBite Backend is Working! 🍎🍌🍊🥭");
});

// ==========================================
// DATABASE TEST
// ==========================================

app.get("/api/test-db", async (req, res) => {

    try {

        const result = await pool.query("SELECT NOW()");

        res.json({
            success: true,
            message: "PostgreSQL connected successfully!",
            time: result.rows[0].now
        });

    } catch (error) {

        console.error("Database test error:", error);

        res.status(500).json({
            success: false,
            message: "Database connection failed"
        });

    }

});

// ==========================================
// JWT AUTHENTICATION
// ==========================================

function authenticateToken(req, res, next) {

    const authHeader = req.headers.authorization;

    const token =
        authHeader &&
        authHeader.split(" ")[1];

    if (!token) {

        return res.status(401).json({
            success: false,
            message: "Authentication required"
        });

    }

    try {

        const decoded = jwt.verify(
            token,
            JWT_SECRET
        );

        req.user = decoded;

        next();

    } catch (error) {

        return res.status(401).json({
            success: false,
            message: "Invalid or expired token"
        });

    }

}

// ==========================================
// ADMIN AUTHENTICATION
// ==========================================

function requireAdmin(req, res, next) {

    if (
        !req.user ||
        req.user.role !== "admin"
    ) {

        return res.status(403).json({
            success: false,
            message: "Admin access required"
        });

    }

    next();

}

// ==========================================
// REGISTER USER
// ==========================================

app.post("/api/register", async (req, res) => {

    try {

        const {
            fullName,
            email,
            phone,
            password
        } = req.body;

        // Check required fields

        if (
            !fullName ||
            !email ||
            !password
        ) {

            return res.status(400).json({
                success: false,
                message:
                    "Name, email and password are required"
            });

        }

        // Check existing email

        const existingUser =
            await pool.query(
                "SELECT id FROM users WHERE email = $1",
                [email]
            );

        if (
            existingUser.rows.length > 0
        ) {

            return res.status(409).json({
                success: false,
                message:
                    "Email already registered"
            });

        }

        // Hash password

        const passwordHash =
            await bcrypt.hash(
                password,
                10
            );

        // Insert user

        const result =
            await pool.query(
                `INSERT INTO users
                (
                    full_name,
                    email,
                    phone,
                    password_hash
                )
                VALUES
                (
                    $1,
                    $2,
                    $3,
                    $4
                )
                RETURNING
                    id,
                    full_name,
                    email,
                    phone,
                    role,
                    created_at`,
                [
                    fullName,
                    email,
                    phone || null,
                    passwordHash
                ]
            );

        res.status(201).json({

            success: true,

            message:
                "Account created successfully!",

            user:
                result.rows[0]

        });

    } catch (error) {

        console.error(
            "Registration error:",
            error
        );

        res.status(500).json({

            success: false,

            message:
                "Server error while creating account"

        });

    }

});

// ==========================================
// LOGIN USER
// ==========================================

app.post("/api/login", async (req, res) => {

    try {

        const {
            email,
            password
        } = req.body;

        // Check required fields

        if (
            !email ||
            !password
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Email and password are required"

            });

        }

        // Find user

        const result =
            await pool.query(
                `SELECT
                    id,
                    full_name,
                    email,
                    phone,
                    password_hash,
                    role
                 FROM users
                 WHERE email = $1`,
                [email]
            );

        if (
            result.rows.length === 0
        ) {

            return res.status(401).json({

                success: false,

                message:
                    "Invalid email or password"

            });

        }

        const user =
            result.rows[0];

        // Check password

        const passwordMatch =
            await bcrypt.compare(
                password,
                user.password_hash
            );

        if (!passwordMatch) {

            return res.status(401).json({

                success: false,

                message:
                    "Invalid email or password"

            });

        }

        // Create JWT

        const token =
            jwt.sign(
                {
                    id: user.id,
                    email: user.email,
                    role: user.role
                },
                JWT_SECRET,
                {
                    expiresIn: "7d"
                }
            );

        // Remove password hash

        delete user.password_hash;

        res.json({

            success: true,

            message:
                "Login successful!",

            token: token,

            user: user

        });

    } catch (error) {

        console.error(
            "Login error:",
            error
        );

        res.status(500).json({

            success: false,

            message:
                "Server error during login"

        });

    }

});

// ==========================================
// GET ALL ACTIVE PRODUCTS
// ==========================================

app.get("/api/products", async (req, res) => {

    try {

        const result =
            await pool.query(
                `SELECT
                    id,
                    name,
                    category,
                    description,
                    price,
                    weight,
                    image_url,
                    stock
                 FROM products
                 WHERE is_active = TRUE
                 ORDER BY id ASC`
            );

        res.json({

            success: true,

            products:
                result.rows

        });

    } catch (error) {

        console.error(
            "Products error:",
            error
        );

        res.status(500).json({

            success: false,

            message:
                "Unable to load products"

        });

    }

});

// ==========================================
// ADMIN - TEST
// ==========================================

app.get(
    "/api/admin/test",
    authenticateToken,
    requireAdmin,
    (req, res) => {

        res.json({

            success: true,

            message:
                "Welcome Admin! 👑",

            user:
                req.user

        });

    }
);

// ==========================================
// ADMIN - ADD PRODUCT
// ==========================================

app.post(
    "/api/admin/products",
    authenticateToken,
    requireAdmin,
    async (req, res) => {

        try {

            const {
                name,
                category,
                description,
                price,
                weight,
                image_url,
                stock
            } = req.body;

            // Validate fields

            if (
                !name ||
                !category ||
                price === undefined ||
                stock === undefined
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Name, category, price and stock are required"

                });

            }

            const priceNumber =
                Number(price);

            const stockNumber =
                Number(stock);

            if (
                !Number.isFinite(priceNumber) ||
                priceNumber < 0
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid price"

                });

            }

            if (
                !Number.isInteger(stockNumber) ||
                stockNumber < 0
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid stock"

                });

            }

            // Insert product

            const result =
                await pool.query(
                    `INSERT INTO products
                    (
                        name,
                        category,
                        description,
                        price,
                        weight,
                        image_url,
                        stock
                    )
                    VALUES
                    (
                        $1,
                        $2,
                        $3,
                        $4,
                        $5,
                        $6,
                        $7
                    )
                    RETURNING *`,
                    [
                        name,
                        category,
                        description || "",
                        priceNumber,
                        weight || "1 kg",
                        image_url || "🍎",
                        stockNumber
                    ]
                );

            res.status(201).json({

                success: true,

                message:
                    "Product added successfully!",

                product:
                    result.rows[0]

            });

        } catch (error) {

            console.error(
                "Add product error:",
                error
            );

            res.status(500).json({

                success: false,

                message:
                    "Failed to add product"

            });

        }

    }
);

// ==========================================
// ADMIN - EDIT PRODUCT
// ==========================================

app.put(
    "/api/admin/products/:id",
    authenticateToken,
    requireAdmin,
    async (req, res) => {

        try {

            const productId =
                req.params.id;

            const {
                name,
                category,
                description,
                price,
                weight,
                image_url,
                stock
            } = req.body;

            // Validate fields

            if (
                !name ||
                !category ||
                price === undefined ||
                stock === undefined
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Name, category, price and stock are required"

                });

            }

            const priceNumber =
                Number(price);

            const stockNumber =
                Number(stock);

            if (
                !Number.isFinite(priceNumber) ||
                priceNumber < 0
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid price"

                });

            }

            if (
                !Number.isInteger(stockNumber) ||
                stockNumber < 0
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid stock"

                });

            }

            // Update product

            const result =
                await pool.query(
                    `UPDATE products
                     SET
                        name = $1,
                        category = $2,
                        description = $3,
                        price = $4,
                        weight = $5,
                        image_url = $6,
                        stock = $7,
                        updated_at = CURRENT_TIMESTAMP
                     WHERE id = $8
                     RETURNING *`,
                    [
                        name,
                        category,
                        description || "",
                        priceNumber,
                        weight || "1 kg",
                        image_url || "🍎",
                        stockNumber,
                        productId
                    ]
                );

            if (
                result.rows.length === 0
            ) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Product not found"

                });

            }

            res.json({

                success: true,

                message:
                    "Product updated successfully!",

                product:
                    result.rows[0]

            });

        } catch (error) {

            console.error(
                "Edit product error:",
                error
            );

            res.status(500).json({

                success: false,

                message:
                    "Failed to update product"

            });

        }

    }
);

// ==========================================
// ADMIN - DELETE PRODUCT
// ==========================================

app.delete(
    "/api/admin/products/:id",
    authenticateToken,
    requireAdmin,
    async (req, res) => {

        try {

            const productId =
                req.params.id;

            // Soft delete

            const result =
                await pool.query(
                    `UPDATE products
                     SET
                        is_active = FALSE,
                        updated_at = CURRENT_TIMESTAMP
                     WHERE id = $1
                     RETURNING id, name`,
                    [productId]
                );

            if (
                result.rows.length === 0
            ) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Product not found"

                });

            }

            res.json({

                success: true,

                message:
                    "Product deleted successfully!",

                product:
                    result.rows[0]

            });

        } catch (error) {

            console.error(
                "Delete product error:",
                error
            );

            res.status(500).json({

                success: false,

                message:
                    "Failed to delete product"

            });

        }

    }
);

// ==========================================
// CREATE ORDER - COD
// ==========================================

app.post(
    "/api/orders",
    authenticateToken,
    async (req, res) => {

        const client =
            await pool.connect();

        let transactionStarted =
            false;

        try {

            const {
                items,
                shipping_name,
                shipping_phone,
                shipping_address,
                payment_method
            } = req.body;

            // ==========================================
            // CHECK CART
            // ==========================================

            if (
                !items ||
                !Array.isArray(items) ||
                items.length === 0
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Cart is empty"

                });

            }

            // ==========================================
            // CHECK DELIVERY DETAILS
            // ==========================================

            if (
                !shipping_name ||
                !shipping_phone ||
                !shipping_address
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Delivery details are required"

                });

            }

            // ==========================================
            // CHECK PAYMENT METHOD
            // ==========================================

            if (
                payment_method !== "cod"
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Only Cash on Delivery is available"

                });

            }

            // ==========================================
            // START TRANSACTION
            // ==========================================

            await client.query("BEGIN");

            transactionStarted = true;

            let subtotal = 0;

            const orderItems = [];

            // ==========================================
            // CHECK PRODUCTS
            // ==========================================

            for (const item of items) {

                const productResult =
                    await client.query(
                        `SELECT
                            id,
                            name,
                            price,
                            stock,
                            is_active
                         FROM products
                         WHERE id = $1
                         FOR UPDATE`,
                        [item.id]
                    );

                if (
                    productResult.rows.length === 0
                ) {

                    throw new Error(
                        `Product not found: ${item.id}`
                    );

                }

                const product =
                    productResult.rows[0];

                // Check active

                if (
                    !product.is_active
                ) {

                    throw new Error(
                        `${product.name} is no longer available`
                    );

                }

                // Quantity

                const quantity =
                    Number(item.quantity);

                if (
                    !Number.isInteger(quantity) ||
                    quantity <= 0
                ) {

                    throw new Error(
                        `Invalid quantity for ${product.name}`
                    );

                }

                // Stock

                if (
                    quantity > product.stock
                ) {

                    throw new Error(
                        `Not enough stock for ${product.name}. Available: ${product.stock}`
                    );

                }

                // Price from database

                const price =
                    Number(product.price);

                const itemSubtotal =
                    price * quantity;

                subtotal +=
                    itemSubtotal;

                orderItems.push({

                    product_id:
                        product.id,

                    product_name:
                        product.name,

                    quantity:
                        quantity,

                    price:
                        price,

                    subtotal:
                        itemSubtotal

                });

            }

            // ==========================================
            // DELIVERY CHARGE
            // ==========================================

            const deliveryCharge =
                subtotal >= 500
                    ? 0
                    : 40;

            // ==========================================
            // TOTAL
            // ==========================================

            const totalAmount =
                subtotal +
                deliveryCharge;

            // ==========================================
            // ORDER NUMBER
            // ==========================================

            const orderNumber =
                "FB" +
                Date.now();

            // ==========================================
            // INSERT ORDER
            // ==========================================

            const orderResult =
                await client.query(
                    `INSERT INTO orders
                    (
                        user_id,
                        order_number,
                        total_amount,
                        delivery_charge,
                        status,
                        payment_status,
                        payment_method,
                        shipping_name,
                        shipping_phone,
                        shipping_address
                    )
                    VALUES
                    (
                        $1,
                        $2,
                        $3,
                        $4,
                        'pending',
                        'pending',
                        $5,
                        $6,
                        $7,
                        $8
                    )
                    RETURNING *`,
                    [
                        req.user.id,
                        orderNumber,
                        totalAmount,
                        deliveryCharge,
                        payment_method,
                        shipping_name,
                        shipping_phone,
                        shipping_address
                    ]
                );

            const order =
                orderResult.rows[0];

            // ==========================================
            // INSERT ORDER ITEMS
            // ==========================================

            for (
                const item
                of orderItems
            ) {

                await client.query(
                    `INSERT INTO order_items
                    (
                        order_id,
                        product_id,
                        product_name,
                        quantity,
                        price,
                        subtotal
                    )
                    VALUES
                    (
                        $1,
                        $2,
                        $3,
                        $4,
                        $5,
                        $6
                    )`,
                    [
                        order.id,
                        item.product_id,
                        item.product_name,
                        item.quantity,
                        item.price,
                        item.subtotal
                    ]
                );

                // ==========================================
                // REDUCE STOCK
                // ==========================================

                await client.query(
                    `UPDATE products
                     SET
                        stock = stock - $1,
                        updated_at = CURRENT_TIMESTAMP
                     WHERE id = $2`,
                    [
                        item.quantity,
                        item.product_id
                    ]
                );

            }

            // ==========================================
            // COMMIT
            // ==========================================

            await client.query(
                "COMMIT"
            );

            transactionStarted =
                false;

            // ==========================================
            // SUCCESS RESPONSE
            // ==========================================

            res.status(201).json({

                success: true,

                message:
                    "Order created successfully",

                order:
                    order

            });

        } catch (error) {

            // Rollback only if transaction started

            if (
                transactionStarted
            ) {

                await client.query(
                    "ROLLBACK"
                );

            }

            console.error(
                "Create order error:",
                error
            );

            res.status(500).json({

                success: false,

                message:
                    error.message ||
                    "Failed to create order"

            });

        } finally {

            client.release();

        }

    }
);
// ==========================================
// CUSTOMER - GET MY ORDERS
// ==========================================

app.get(
    "/api/my-orders",
    authenticateToken,
    async (req, res) => {

        try {

            const result = await pool.query(
                `SELECT
                    id,
                    order_number,
                    total_amount,
                    delivery_charge,
                    status,
                    payment_status,
                    payment_method,
                    shipping_name,
                    shipping_phone,
                    shipping_address,
                    created_at,
                    updated_at
                 FROM orders
                 WHERE user_id = $1
                 ORDER BY created_at DESC`,
                [req.user.id]
            );

            res.json({
                success: true,
                orders: result.rows
            });

        } catch (error) {

            console.error(
                "My orders error:",
                error
            );

            res.status(500).json({
                success: false,
                message: "Unable to load your orders"
            });

        }

    }
);
// ==========================================
// CUSTOMER - GET ORDER DETAILS
// ==========================================

app.get(
    "/api/my-orders/:id",
    authenticateToken,
    async (req, res) => {

        try {

            const orderId = req.params.id;

            // Get order
            const orderResult = await pool.query(
                `SELECT
                    id,
                    order_number,
                    total_amount,
                    delivery_charge,
                    status,
                    payment_status,
                    payment_method,
                    shipping_name,
                    shipping_phone,
                    shipping_address,
                    created_at,
                    updated_at
                 FROM orders
                 WHERE id = $1
                 AND user_id = $2`,
                [
                    orderId,
                    req.user.id
                ]
            );

            if (orderResult.rows.length === 0) {

                return res.status(404).json({
                    success: false,
                    message: "Order not found"
                });

            }

            const order = orderResult.rows[0];

            // Get order items
            const itemsResult = await pool.query(
                `SELECT
                    id,
                    product_id,
                    product_name,
                    quantity,
                    price,
                    subtotal
                 FROM order_items
                 WHERE order_id = $1
                 ORDER BY id ASC`,
                [orderId]
            );

            res.json({
                success: true,
                order: order,
                items: itemsResult.rows
            });

        } catch (error) {

            console.error(
                "Customer order details error:",
                error
            );

            res.status(500).json({
                success: false,
                message: "Unable to load order details"
            });

        }

    }
);

// ==========================================
// ADMIN - GET ALL ORDERS
// ==========================================

app.get(
    "/api/admin/orders",
    authenticateToken,
    requireAdmin,
    async (req, res) => {

        try {

            const result = await pool.query(
                `SELECT
                    o.id,
                    o.order_number,
                    o.total_amount,
                    o.delivery_charge,
                    o.status,
                    o.payment_status,
                    o.payment_method,
                    o.shipping_name,
                    o.shipping_phone,
                    o.shipping_address,
                    o.created_at,
                    o.updated_at,

                    u.email AS customer_email

                 FROM orders o

                 JOIN users u
                 ON o.user_id = u.id

                 ORDER BY o.created_at DESC`
            );

            res.json({

                success: true,

                orders: result.rows

            });

        } catch (error) {

            console.error(
                "Admin orders error:",
                error
            );

            res.status(500).json({

                success: false,

                message:
                    "Failed to load orders"

            });

        }

    }
);

// ==========================================
// ADMIN - GET ORDER DETAILS
// ==========================================

app.get(
    "/api/admin/orders/:id",
    authenticateToken,
    requireAdmin,
    async (req, res) => {

        try {

            const orderId =
                req.params.id;

            // Get order information

            const orderResult =
                await pool.query(
                    `SELECT
                        o.id,
                        o.order_number,
                        o.total_amount,
                        o.delivery_charge,
                        o.status,
                        o.payment_status,
                        o.payment_method,
                        o.shipping_name,
                        o.shipping_phone,
                        o.shipping_address,
                        o.created_at,
                        o.updated_at,

                        u.email AS customer_email

                     FROM orders o

                     JOIN users u
                     ON o.user_id = u.id

                     WHERE o.id = $1`,
                    [orderId]
                );

            // Check order

            if (
                orderResult.rows.length === 0
            ) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Order not found"

                });

            }

            // Get order items

            const itemsResult =
                await pool.query(
                    `SELECT
                        id,
                        product_id,
                        product_name,
                        quantity,
                        price,
                        subtotal

                     FROM order_items

                     WHERE order_id = $1

                     ORDER BY id ASC`,
                    [orderId]
                );

            res.json({

                success: true,

                order:
                    orderResult.rows[0],

                items:
                    itemsResult.rows

            });

        } catch (error) {

            console.error(
                "Admin order details error:",
                error
            );

            res.status(500).json({

                success: false,

                message:
                    "Failed to load order details"

            });

        }

    }
);
// ==========================================
// ADMIN - UPDATE ORDER STATUS
// ==========================================

app.put(
    "/api/admin/orders/:id/status",
    authenticateToken,
    requireAdmin,
    async (req, res) => {

        try {

            const orderId =
                req.params.id;

            const {
                status
            } = req.body;

            // Allowed statuses

            const allowedStatuses = [

                "pending",

                "confirmed",

                "preparing",

                "out_for_delivery",

                "delivered",

                "cancelled"

            ];

            // Check status

            if (
                !allowedStatuses.includes(status)
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid order status"

                });

            }

            // Update order

            const result =
                await pool.query(
                    `UPDATE orders

                     SET
                        status = $1,
                        updated_at = CURRENT_TIMESTAMP

                     WHERE id = $2

                     RETURNING *`,
                    [
                        status,
                        orderId
                    ]
                );

            // Order not found

            if (
                result.rows.length === 0
            ) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Order not found"

                });

            }

            res.json({

                success: true,

                message:
                    "Order status updated successfully",

                order:
                    result.rows[0]

            });

        } catch (error) {

            console.error(
                "Update order status error:",
                error
            );

            res.status(500).json({

                success: false,

                message:
                    "Failed to update order status"

            });

        }

    }
);

// ================= ADMIN ORDERS =================

// GET ALL ORDERS - ADMIN
app.get(
    "/api/admin/orders",
    authenticateToken,
    requireAdmin,
    async (req, res) => {
        try {
            const result = await pool.query(
                `SELECT
                    o.id,
                    o.order_number,
                    o.total_amount,
                    o.delivery_charge,
                    o.status,
                    o.payment_status,
                    o.payment_method,
                    o.shipping_name,
                    o.shipping_phone,
                    o.shipping_address,
                    o.created_at,
                    o.updated_at,
                    u.email AS customer_email
                 FROM orders o
                 JOIN users u ON o.user_id = u.id
                 ORDER BY o.created_at DESC`
            );

            res.json({
                success: true,
                orders: result.rows
            });

        } catch (error) {
            console.error("Admin orders error:", error);

            res.status(500).json({
                success: false,
                message: "Failed to load orders"
            });
        }
    }
);


// GET SINGLE ORDER - ADMIN
app.get(
    "/api/admin/orders/:id",
    authenticateToken,
    requireAdmin,
    async (req, res) => {
        try {
            const orderId = req.params.id;

            const orderResult = await pool.query(
                `SELECT
                    o.id,
                    o.order_number,
                    o.total_amount,
                    o.delivery_charge,
                    o.status,
                    o.payment_status,
                    o.payment_method,
                    o.shipping_name,
                    o.shipping_phone,
                    o.shipping_address,
                    o.created_at,
                    o.updated_at,
                    u.email AS customer_email
                 FROM orders o
                 JOIN users u
                 ON o.user_id = u.id
                 WHERE o.id = $1`,
                [orderId]
            );

            if (orderResult.rows.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Order not found"
                });
            }

            const itemsResult = await pool.query(
                `SELECT
                    id,
                    product_id,
                    product_name,
                    quantity,
                    price,
                    subtotal
                 FROM order_items
                 WHERE order_id = $1
                 ORDER BY id ASC`,
                [orderId]
            );

            res.json({
                success: true,
                order: orderResult.rows[0],
                items: itemsResult.rows
            });

        } catch (error) {
            console.error("Admin order details error:", error);

            res.status(500).json({
                success: false,
                message: "Failed to load order details"
            });
        }
    }
);


// UPDATE ORDER STATUS - ADMIN
app.put(
    "/api/admin/orders/:id/status",
    authenticateToken,
    requireAdmin,
    async (req, res) => {
        try {
            const orderId = req.params.id;
            const { status } = req.body;

            const allowedStatuses = [
                "pending",
                "confirmed",
                "preparing",
                "out_for_delivery",
                "delivered",
                "cancelled"
            ];

            if (!allowedStatuses.includes(status)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid order status"
                });
            }

            const result = await pool.query(
                `UPDATE orders
                 SET status = $1,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $2
                 RETURNING *`,
                [status, orderId]
            );

            if (result.rows.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Order not found"
                });
            }

            res.json({
                success: true,
                message: "Order status updated successfully",
                order: result.rows[0]
            });

        } catch (error) {
            console.error("Update order status error:", error);

            res.status(500).json({
                success: false,
                message: "Failed to update order status"
            });
        }
    }
);


// ==========================================
// START SERVER
// ==========================================

app.listen(
    PORT,
    () => {

        console.log(
            `🚀 Server running at http://localhost:${PORT}`
        );

    }
);