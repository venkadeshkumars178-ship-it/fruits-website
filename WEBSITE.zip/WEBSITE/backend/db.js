const { Pool } = require("pg");

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "freshbite",
    password: "9790781454",
    port: 5432
});

pool.connect()
    .then(() => {
        console.log("✅ PostgreSQL connected successfully!");
    })
    .catch((error) => {
        console.error("❌ PostgreSQL connection failed:");
        console.error(error.message);
    });

module.exports = pool;